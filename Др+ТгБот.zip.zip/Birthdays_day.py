import os
import logging
import traceback
from datetime import datetime, timedelta
import gspread
from telebot import TeleBot
from oauth2client.service_account import ServiceAccountCredentials
from dotenv import load_dotenv

load_dotenv()

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")
GOOGLE_SHEETS_KEY = os.getenv("GOOGLE_SHEETS_KEY")
GOOGLE_CREDENTIALS_PATH = os.getenv("GOOGLE_CREDENTIALS_PATH")

def create_logger(file_name: str, name: str):
    if not os.path.exists(f'logs/{name}'):
        os.makedirs(f'logs/{name}')
    path = f'logs/{name}/{file_name}'

    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)

    formatter = logging.Formatter(fmt='[%(asctime)s - %(levelname)s - %(funcName)s] %(message)s',
                                  datefmt='%d.%m.%Y %H:%M:%S')

    file_log = logging.FileHandler(path, encoding="UTF-8")
    file_log.setFormatter(formatter)

    console_out = logging.StreamHandler()
    console_out.setFormatter(formatter)

    logger.addHandler(file_log)
    logger.addHandler(console_out)

    return logger

logger = create_logger("daily_birthdays.log", "DailyBirthdays")

def get_birthdays_data():
    logger.info("Начало получения данных из Google Sheets...")
    try:
        scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/spreadsheets",
                 "https://www.googleapis.com/auth/drive.file", "https://www.googleapis.com/auth/drive"]
        creds = ServiceAccountCredentials.from_json_keyfile_name(GOOGLE_CREDENTIALS_PATH, scope)
        client = gspread.authorize(creds)

        sheet = client.open_by_key(GOOGLE_SHEETS_KEY).sheet1
        data = sheet.get_all_records()
        logger.info("Данные успешно получены из Google Sheets!")
        return data
    except Exception as e:
        logger.error(f"Ошибка при подключении к Google Sheets: {traceback.format_exc()}")
        return []

def filter_birthdays(data, delta_days):
    today = datetime.now()
    target_date = today + timedelta(days=delta_days)
    filtered_birthdays = []

    for person in data:
        birth_date_str = person['ДР']
        if birth_date_str:
            try:
                birth_date = datetime.strptime(birth_date_str, '%d.%m.%Y')
                if birth_date.month == target_date.month and birth_date.day == target_date.day:
                    filtered_birthdays.append(person)
            except ValueError:
                logger.warning(f"Ошибка формата даты: {birth_date_str} у {person['ФИО']}")
    logger.info(f"Найдено {len(filtered_birthdays)} именинников для даты {target_date.strftime('%d.%m.%Y')}.")
    return filtered_birthdays

def format_daily_message(data, time_period):
    logger.info(f"Форматирование сообщения для периода: {time_period}.")
    message = f"Дни рождения {time_period}:\n\n"
    for person in data:
        message += (f"<b>{person['Аббревиатура']}</b>:\n"
                    f"<b>{person['ФИО']}</b>\n"
                    f"{person.get('Должность', 'Должность не указана')}\n"
                    f"{person.get('Телефон', 'Телефон не указан')}\n"
                    f"{person['ДР']}\n\n")
    return message

def send_telegram_message(bot_token, chat_id, message):
    logger.info("Отправка сообщения в Telegram...")
    try:
        bot = TeleBot(bot_token, parse_mode="HTML")
        bot.send_message(chat_id=chat_id, text=message)
        logger.info("Сообщение успешно отправлено!")
    except Exception as e:
        logger.error(f"Ошибка при отправке сообщения в Telegram: {traceback.format_exc()}")

def daily_birthdays_reminder():
    logger.info("Запуск напоминания о днях рождения...")
    data = get_birthdays_data()

    today_birthdays = filter_birthdays(data, 0)
    three_days_birthdays = filter_birthdays(data, 3)
    week_birthdays = filter_birthdays(data, 7)

    full_message = ""

    if today_birthdays:
        message_today = format_daily_message(today_birthdays, "сегодня")
        full_message += message_today

    if three_days_birthdays:
        message_three_days = format_daily_message(three_days_birthdays, "через 3 дня")
        full_message += message_three_days

    if week_birthdays:
        message_week = format_daily_message(week_birthdays, "через неделю")
        full_message += message_week

    if full_message:
        send_telegram_message(TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, full_message)
    else:
        logger.info("Нет именинников для отправки в Telegram сегодня.")

if __name__ == "__main__":
    logger.info("Запуск основного скрипта...")
    daily_birthdays_reminder()
