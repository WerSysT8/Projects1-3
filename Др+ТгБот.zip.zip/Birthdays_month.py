import os
import logging
import gspread
from google.oauth2.service_account import Credentials
from telebot import TeleBot
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")
GOOGLE_SHEETS_KEY = os.getenv("GOOGLE_SHEETS_KEY")
GOOGLE_CREDENTIALS_PATH = os.getenv("GOOGLE_CREDENTIALS_PATH")

MONTHS_IN_GENITIVE = {
    1: "январе",
    2: "феврале",
    3: "марте",
    4: "апреле",
    5: "мае",
    6: "июне",
    7: "июле",
    8: "августе",
    9: "сентябре",
    10: "октябре",
    11: "ноябре",
    12: "декабре"
}

def create_logger(file_name: str, name: str):
    if not os.path.exists(f'logs/{name}'):
        os.makedirs(f'logs/{name}')
    path = f'logs/{name}/{file_name}'

    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)

    file_log = logging.FileHandler(path, encoding="UTF-8")
    formatter = logging.Formatter(fmt='[%(asctime)s - %(levelname)s - %(funcName)s] %(message)s',
                                            datefmt='%d.%m.%Y %H:%M:%S')
    file_log.setFormatter(formatter)

    console_out = logging.StreamHandler()
    console_out.setFormatter(formatter)

    logger.addHandler(file_log)
    logger.addHandler(console_out)

    return logger

logger = create_logger("birthday_reminder.log", "BirthdayReminder")

def get_birthdays_data():
    logger.info("Начало получения данных из Google Sheets...")
    try:
        scope = ["https://www.googleapis.com/auth/spreadsheets", "https://www.googleapis.com/auth/drive"]
        creds = Credentials.from_service_account_file(GOOGLE_CREDENTIALS_PATH, scopes=scope)
        client = gspread.authorize(creds)

        sheet = client.open_by_key(GOOGLE_SHEETS_KEY).sheet1
        data = sheet.get_all_records()
        logger.info("Данные успешно получены из Google Sheets!")
        return data
    except Exception as e:
        logger.error(f"Ошибка при подключении к Google Sheets: {e}")
        return []

def format_monthly_message(data, month):
    logger.info("Форматирование сообщения для текущего месяца...")
    month_name = MONTHS_IN_GENITIVE.get(month, "неизвестном месяце")
    message = f"Дни рождения в {month_name.capitalize()}:\n\n"
    sorted_data = sorted(data, key=lambda x: x['ДР'])

    for person in sorted_data:
        birth_date_str = person['ДР']
        if birth_date_str:
            try:
                birth_date = datetime.strptime(birth_date_str, '%d.%m.%Y')
                if birth_date.month == month:
                    message += f"{person['ФИО']} — {person['Аббревиатура']} — {birth_date.strftime('%d.%m')}\n\n"
            except ValueError:
                logger.warning(f"Ошибка формата даты: {birth_date_str} у {person['ФИО']}")
    if "Дни рождения в" in message:
        logger.info("Сообщение успешно сформировано!")
    else:
        logger.info("Нет именинников в этом месяце.")
    return message

def send_telegram_message_and_pin(bot_token, chat_id, message):
    logger.info("Отправка сообщения в Telegram...")
    try:
        bot = TeleBot(bot_token)
        sent_message = bot.send_message(chat_id, message, parse_mode="Markdown")
        bot.pin_chat_message(chat_id, sent_message.message_id)
        logger.info("Сообщение успешно отправлено и закреплено!")
    except Exception as e:
        logger.error(f"Ошибка при отправке сообщения в Telegram: {e}")

def monthly_birthdays_reminder():
    logger.info("Запуск напоминания о днях рождения...")
    data = get_birthdays_data()
    if not data:
        logger.error("Ошибка: нет данных для отправки!")
        return

    month = datetime.now().month
    message = format_monthly_message(data, month)

    if message.strip():
        send_telegram_message_and_pin(TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, message)
    else:
        logger.info("Нет данных для отправки за текущий месяц.")

if __name__ == "__main__":
    logger.info("Запуск основного скрипта...")
    monthly_birthdays_reminder()
